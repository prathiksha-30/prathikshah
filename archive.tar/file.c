hello pinky
